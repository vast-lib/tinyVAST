

library(testthat)
library(tinyVAST)

# Run tests
testthat::test_check("tinyVAST")

# Run from local directory
# testthat::test_dir( "C:/Users/James.Thorson/Desktop/Git/tinyVAST/tests/testthat/", reporter="check" )
# testthat::test_local(path = "C:/Users/James.Thorson/Desktop/Git/tinyVAST" )
